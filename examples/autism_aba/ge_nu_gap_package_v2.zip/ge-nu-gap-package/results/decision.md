# Gap‑Effect Decision
- Primary metric: **IDKPTM**
- SESOI: level ±0.1, slope ±0.005/session
- Permutations: 1000 (circular label shifts)

## Per‑participant
- Aden: possible_effect (Δ_L=0.267, Δ_T=0.0491, p_L=0.137, p_T=0.137)
- Alex: possible_effect (Δ_L=0.254, Δ_T=0.02, p_L=0.134, p_T=0.134)
- Ida: possible_effect (Δ_L=0.264, Δ_T=0.031, p_L=0.134, p_T=0.134)

### Notes
- Weighted means and slopes use **w_t = 1/(u_t+ε)** with u_t built from IOA and fidelity.
- Decisions require both stats to be within SESOI and permutation p‑values > 0.10.
- Re‑run with `--metric Correct` as a sensitivity check and include the ‘5‑targets’ sessions as a second run.