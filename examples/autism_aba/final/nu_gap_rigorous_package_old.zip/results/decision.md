# Gap‑Effect Decision (N/U weighted)
- SESOI: level ±0.1, slope ±0.005/session
- Permutations: 5000 (circular label shifts)

## Per‑participant
- Aden: possible_effect (Δ_L=-0.948, Δ_T=-0.415, p_L=0.728, p_T=0.028; n_pre=20, n_post=15)
- Alex: insufficient pre/post data
- Ida: insufficient pre/post data