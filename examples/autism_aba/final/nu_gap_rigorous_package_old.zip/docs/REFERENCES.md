# REFERENCES
- Swensson, R. M., et al. (2024). Teaching children with ASD to mand for answers via telehealth: A caregiver implementation. *Behavioral Interventions*, 39(3), e2015.
- Martin, E. D. (2025). The NASA Paper & Small Falcon Algebra (preprint): Lean N/U Core v1 operations and invariants.
